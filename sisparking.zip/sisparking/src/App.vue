<template>
  <Nav/>

  <main class="form-signin">
    <router-view/>
  </main>
</template>

<script>

import Nav from "@/components/Nav";

export default {
  components: {Nav}
}

</script>

<style>
.form-signin {
  width: 100%;
  max-width: 330px;
  padding: 15px;
  margin: auto;
}
.form-signin .checkbox {
  font-weight: 400;
}
.form-signin .form-control {
  position: relative;
  box-sizing: border-box;
  height: auto;
  padding: 10px;
  font-size: 16px;
}
.form-signin .form-control:focus {
  z-index: 2;
}
.form-signin input[type="email"] {
  margin-bottom: -1px;
  border-bottom-right-radius: 0;
  border-bottom-left-radius: 0;
}
.form-signin input[type="password"] {
  margin-bottom: 10px;
  border-top-left-radius: 0;
  border-top-right-radius: 0;
}
.padre {
  height: 100px;
  width: 100px;
  background: black;
  /* Codigo para centrar*/
  display: flex;
  justify-content: center;
  align-items: center;
  /* Fin del codigo para centrar*/
}
.hijo {
  height: 10px;
  width: 10px;
  background: red;
}
</style>